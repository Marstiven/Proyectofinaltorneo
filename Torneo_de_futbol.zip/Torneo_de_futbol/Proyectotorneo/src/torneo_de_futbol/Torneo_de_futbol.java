
package torneo_de_futbol;

/**
 *
 * @author ADMIN
 */
public class Torneo_de_futbol {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Yeaahhh buddy");
    }
    
}
