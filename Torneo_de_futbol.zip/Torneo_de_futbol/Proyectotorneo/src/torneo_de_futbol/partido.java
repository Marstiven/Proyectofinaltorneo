package torneo_de_futbol;

import java.util.Date;

/**
 *
 * @author ADMIN
 */
public class partido {
    private Date Fecha;
    private String equipoL;
    private String goles_equipoL;
    private String equipoV;
    private String goles_equipoV;

    public partido() {
    }

    public partido(Date Fecha, String equipoL, String goles_equipoL, String equipoV, String goles_equipoV) {
        this.Fecha = Fecha;
        this.equipoL = equipoL;
        this.goles_equipoL = goles_equipoL;
        this.equipoV = equipoV;
        this.goles_equipoV = goles_equipoV;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date fecha) {
        this.Fecha = Fecha;
    }

    public String getEquipoL() {
        return equipoL;
    }

    public void setEquipoL(String equipoL) {
        this.equipoL = equipoL;
    }

    public String getGoles_equipoL() {
        return goles_equipoL;
    }

    public void setGoles_equipoL(String goles_equipoL) {
        this.goles_equipoL = goles_equipoL;
    }

    public String getEquipoV() {
        return equipoV;
    }

    public void setEquipoV(String equipoV) {
        this.equipoV = equipoV;
    }

    public String getGoles_equipoV() {
        return goles_equipoV;
    }

    public void setGoles_equipoV(String goles_equipoV) {
        this.goles_equipoV = goles_equipoV;
    }
    
    

  
    }
    
    

