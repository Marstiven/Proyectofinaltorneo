package torneo_de_futbol;

import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class conexion {
    static Connection conectar;
    String usuario = "root";
    String url="jdbc:mysql://localhost:3306/";
    String contraseña="marcanti77";
    String bd="torneo";
    String ip="localhost";
    String puerto="3306";
    
    String cadena = "jdbc:MySQL://"+ip+":"+puerto+"/"+bd;
    
    public Connection establecerconexion(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection(url+bd, usuario, contraseña);
            System.out.println("Se conecto correctamente a la base de datos**");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            System.out.println("NO se conecto a la base de datos!!!");
        }
        
        return conectar;       
    }
    
    public void desconectar(){
        try {
            conectar.close();
            System.out.println("Se ha desconectado de la base de datos correctamente");
        } catch (SQLException ex) {
            System.out.println("error: "+ex);
        }
    }
    public static void main(String[] args) {
        conexion c1 = new conexion();
        c1.establecerconexion();
    }
}
