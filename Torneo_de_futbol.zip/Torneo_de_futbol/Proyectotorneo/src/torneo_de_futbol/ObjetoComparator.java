
package torneo_de_futbol;

import java.util.Comparator;


public class ObjetoComparator implements Comparator<partido>  {
    
    @Override
    public int compare(partido o1, partido o2) {
        if (o2.getFecha()== null || o1.getFecha()==null){
            return 0;
        }else{
        return o2.getFecha().compareTo(o1.getFecha());
    }
    }
}
